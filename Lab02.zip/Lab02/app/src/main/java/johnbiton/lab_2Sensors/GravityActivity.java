package johnbiton.lab_2Sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.EditText;

import java.text.DecimalFormat;

public class GravityActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor gravity, light, magnetic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        light = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        magnetic = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }

    public final void onAccuracyChanged(Sensor sensor, int accuracy){
        //do something here if sensor accuracy changes
    }

    public final void onSensorChanged(SensorEvent sensorEvent){
        final DecimalFormat df = new DecimalFormat("0.00");
        if(sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY){
            float xaccel = sensorEvent.values[0];
            float yaccel = sensorEvent.values[1];
            float zaccel = sensorEvent.values[2];

            EditText grav_x = findViewById(R.id.gravValue_X);
            grav_x.setText(df.format(xaccel)+ "m/s\u00B2");

            EditText grav_y = findViewById(R.id.gravValue_Y);
            grav_y.setText(df.format(yaccel)+ "m/s\u00B2");

            EditText grav_z = findViewById(R.id.gravValue_Z);
            grav_z.setText(df.format(zaccel)+ "m/s\u00B2");
        }

        if(sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            float xmag = sensorEvent.values[0];
            float ymag = sensorEvent.values[1];
            float zmag = sensorEvent.values[2];

            EditText grav_x = findViewById(R.id.magValue_X);
            grav_x.setText( df.format(xmag)+ "uT");

            EditText grav_y = findViewById(R.id.magValue_Y);
            grav_x.setText( df.format(ymag)+ "uT");

            EditText grav_z = findViewById(R.id.magValue_Z);
            grav_x.setText( df.format(zmag)+ "uT");
        }
    }

    @Override
    protected void onResume(){
        //register a listener for the sensor
        super.onResume();
        sensorManager.registerListener((SensorEventListener) this, gravity, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener((SensorEventListener) this, magnetic, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){

        super.onPause();
        sensorManager.unregisterListener((SensorListener) this);
    }
}